// console.log("Hello World!");


// var v = 10;
// console.log(v);

// let l = 20;
// console.log(l);

// const c = 30;
// console.log(c)


// c = 40;
// console.log(c);


// // function decleration
// function hello(){
//     console.log("This is hello function");
// }

// // function call
// hello();
// hello();



// function isEven(n){
//     if(n%2==0){
//         console.log("It is an Even Number: "+n);
//     } else{
//         console.log("It is an Odd Number: "+n);
//     }
// }

// isEven(10);
// isEven(11);





// console.log(5+10);
// console.log("sum of 5+10=",5+10);
// console.log("sum of 5+10="+5+10);

// // 5 10
// System.out.println(5+10) //15
// System.out.println(5+" "+10) //15







// function add(a,b){
//     return a+b;
// }

// let res = add(10,20);

// console.log(res);






// function hello(){
//     let l;
//     if(true){
//         var v = 10;
//         let l = 20;
//         const c = 30;

//         console.log(v,l,c);
//     }

//     console.log(v);
//     // console.log(l);
//     // console.log(c);
// }

// hello();



// let i = 10; //integer
// let f = 3.14 //float
// let s = "Hello" //string
// let b1 = true // boolean
// let b2 = false //boolean
// let n = null //null typeof() -> object
// let u;


// // console.log(typeof(i))
// // console.log(typeof(f))
// // console.log(typeof(s))
// // console.log(typeof(b1))
// // console.log(typeof(b2))
// // console.log(typeof(n))
// // console.log(typeof(u))




// // 1-10
// for(let i=1; i<=10; i++){
//     console.log(i)
// }


// // 1-10
// let i = 1;
// while(i<=10){
//     console.log(i);
//     i++;
// }




// function isPrime(n){
//     for(let i=2; i<n ;i++){
//         if(n%i==0){
//             console.log("it is a composite number");
//             return 
//         }
//     }
//     console.log("It is a prime number");
// }

// isPrime(11)
















