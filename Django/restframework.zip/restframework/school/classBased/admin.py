from django.contrib import admin

# Register your models here.
from classBased.models import Friends

admin.site.register(Friends)