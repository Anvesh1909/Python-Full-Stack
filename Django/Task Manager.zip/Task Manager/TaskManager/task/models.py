from random import choice, choices
from django.db import models
from django.forms import ChoiceField

from django.db import models

class Tasks(models.Model):

    STATUS_CHOICES = [
        ('TO DO', 'TO DO'),
        ('IN PROCESS', 'In Process'),
        ('DONE', 'Done'),
    ]

    title = models.CharField(max_length=50)
    description = models.TextField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES)
    date = models.DateTimeField(auto_now=True)
